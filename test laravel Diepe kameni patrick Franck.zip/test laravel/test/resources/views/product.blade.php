@extends('layouts.app')

@section('content')

<section >
        <div class="container text-center mt-3 mb-5 bg-info" >
    
            <div class="row">
    
                <div class="col-md-8 mx-auto text-center">
                    
                        <h4 class="font-weight-bold my-3 lang" key="p81">Nouveau produit</h4>

                        <div class="border border-secondary rounded p-4 login-form mb-4" id="car_form">

                            <form action="{{ route('addProduct')}}" method="POST" name="" enctype="multipart/form-data">
                                {{csrf_field()}}
                                <div class="input-group mb-3">
                                    <input type="text" name="nomProduit" class="form-control" id="nomProduit" placeholder="libellé du produit">
                                </div>

                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" id="qteProduit" name="qteProduit" placeholder="Quantité du produit">
                                </div>

                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" id="prixProduit" placeholder="Prix unitaire" name="prixProduit">
                                </div>
                        

                                <div class="input-group my-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            Catégories
                                        </span>
                                    </div>
                                    <select class="form-control" id="categorie" name="categorie">
                                        <option value="0" selected disabled >Choix de catégories</option>
                                        <option value="Electroménager">Electroménager</option>
                                        <option value="Cosmétique" >Cosmétique</option>
                                        <option value="électronique">électronique</option>
                                    </select>
                                </div>
                                
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Upload</span>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image" name="image">
                                        <label class="custom-file-label" for="image">Choix de l'image</label>
                                    </div>
                                </div>
                                                                
                                <button type="submit" class="btn btn-outline-dark btn-block text-uppercase mt-3">
                                    Enregistrez
                                </button>
                            </form>
                        </div>

                    
                </div>
    
            </div>
    
        </div>
    </section>

    @endsection