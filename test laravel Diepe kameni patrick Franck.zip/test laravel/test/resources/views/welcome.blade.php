@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <div class="row p-5">

        @foreach($products as $product)
            <div class="card col-md-6 col-lg-4 col-xl-3 my-3 mx-3" >
                <img class="card-img-top " src="uploads\product\{{$product->imageProduit}}" width="200px" height="200px" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">{{$product->nomProduit}} : {{$product->prixProduit}} FCFA</h5>
                    <p class="card-text">En stock: {{$product->qteProduit}}</p>
                </div>
                <div class="card-footer">
                    <small class="text-muted">Catégorie: {{$product->categorieProduit}}</small>
                </div>
            </div>
        @endforeach
        
    </div>

</div>
   
    @endsection