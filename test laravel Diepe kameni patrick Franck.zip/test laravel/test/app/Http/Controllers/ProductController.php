<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        return view('product');
    }

    public function store(Request $request)
    {
        $product = new Product();

        $product->nomProduit = $request->input('nomProduit');
        $product->qteProduit = $request->input('qteProduit');
        $product->prixProduit = $request->input('prixProduit');
        $product->categorieProduit = $request->input('categorie'); 

        if($request->hasfile('image'))
        {
            $file = $request->file('image');
            $extensiom = $file->getClientOriginalExtension();
            $filename = time().'.'.$extensiom;
            $file->move('uploads/product/', $filename);
            $product->imageProduit = $filename;
        }else
        {
            return $request;
            $product->image = '';
        }

        $product->save();

        return view('product')->with('product',$product);

    }

    public function display()
    {
        $products = Product::all();
        return view('welcome')->with('products',$products);
    }
}
