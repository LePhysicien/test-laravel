<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row p-5">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-md-6 col-lg-4 col-xl-3 my-3 mx-3" >
                <img class="card-img-top " src="uploads\product\<?php echo e($product->imageProduit); ?>" width="200px" height="200px" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($product->nomProduit); ?> : <?php echo e($product->prixProduit); ?> FCFA</h5>
                    <p class="card-text">En stock: <?php echo e($product->qteProduit); ?></p>
                </div>
                <div class="card-footer">
                    <small class="text-muted">Catégorie: <?php echo e($product->categorieProduit); ?></small>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>

</div>
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LePhysicien\Desktop\test laravel\test\resources\views/welcome.blade.php ENDPATH**/ ?>